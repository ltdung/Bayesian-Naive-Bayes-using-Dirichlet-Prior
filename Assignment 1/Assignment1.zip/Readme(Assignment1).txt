1)	To run the python code, either run the .py file or it can be run on jupyter notebook as well using .ipynb file.

2)	To run the code on custom dataset, just change the path of the file in the fr=open('path').

3) The observations are written in ipython notebook. I have also attatched the html file for the ipython notebook for easy viasualisation.
